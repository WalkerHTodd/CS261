/*
 * CS 261 PA0: Intro project
 *
 * Name: 
 */

#include "p0-intro.h"

#include <math.h>

int add_abs (int num1, int num2)
{
    return 0;
}

void add_ptr (int num1, int num2, int *ans)
{
}

int factorial (int num)
{
    return 0;
}

bool is_prime (int num)
{
    return true;
}

vector_t add_vec (vector_t v1, vector_t v2)
{
    vector_t ans = v1;
    return ans;
}

double dot_prod_vec (vector_t v1, vector_t v2)
{
    return 0;
}

int sum_array (int *nums, size_t n)
{
    return -1;
}

int gcd (int num1, int num2)
{
    return 0;
}

void sort_array (int *nums, size_t n)
{
}


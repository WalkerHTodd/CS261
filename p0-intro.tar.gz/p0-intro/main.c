/*
 * CS 261: Intro project driver
 *
 * Name: 
 */

#include "p0-intro.h"

int main (int argc, char **argv)
{
    printf("Hello, CS 261!\n");
    return EXIT_SUCCESS;
}


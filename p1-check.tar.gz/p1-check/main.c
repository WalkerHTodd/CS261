/*
 * CS 261: Main driver
 *
 * Name: 
 */

#include "p1-check.h"

int main (int argc, char **argv)
{
    return EXIT_SUCCESS;
}


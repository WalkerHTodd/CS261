/*
 * CS 261: Main driver
 *
 * Name: 
 */

#include "p1-check.h"
#include "p2-load.h"

int main (int argc, char **argv)
{
    return EXIT_SUCCESS;
}

